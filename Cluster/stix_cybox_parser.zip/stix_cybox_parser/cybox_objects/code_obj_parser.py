class CodeObjParser(object):
	#needs to be filled in
